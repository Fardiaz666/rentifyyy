import { createContext } from 'react';

// This context will be used to provide a toast function to any component
export const ToastContext = createContext();
